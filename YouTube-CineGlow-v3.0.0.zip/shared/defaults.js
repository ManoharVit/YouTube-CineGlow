/**
 * Default settings shared by extension content scripts, popup UI, and service worker.
 * @type {Readonly<Record<string, unknown>>}
 */
var AURA_DEFAULTS = Object.freeze({
  enabled: true,
  adblockEnabled: true,
  sponsorBlockEnabled: true,
  sponsorBlockMode: 'skip',      // 'skip' | 'fastforward'
  sponsorBlockCategories: Object.freeze(['sponsor', 'selfpromo', 'interaction']),
  sponsorBlockNotice: true,
  qualityEnabled: true,
  statsEnabled: false,
  preferredQuality: 'hd1080',
  preferredSpeed: 1.0,
  blockAV1: false,
  blockVP9: false,
  block60fps: false,
  hideInTheater: true,
  hideScrollbar: true,
  enableInPiP: false,
  glowTop: true,
  glowRight: true,
  glowBottom: true,
  glowLeft: true,
  opacity: 90,           // % (balanced, comfortable default)
  fadeInDuration: 1,     // seconds
  blur: 40,              // px
  spread: 200,           // % of video size (concentrated halo, avoids washing over page)
  saturation: 130,       // %
  contrast: 110,         // %
  brightness: 105,       // %
  smoothness: 50,        // % — temporal blend between frames
  removeBlackBars: true,
  fps: 30,               // max glow updates per second
  audioNormalizer: true,
  audioBoost: 100,       // %
  bassBoost: 0,          // dB (0 to 15)
  vocalBoost: 0,         // dB (0 to 12)
  eq60: 0,               // dB (-12 to +12)
  eq250: 0,              // dB (-12 to +12)
  eq1000: 0,             // dB (-12 to +12)
  eq4000: 0,             // dB (-12 to +12)
  eq12000: 0,            // dB (-12 to +12)
  eqPreset: 'flat',      // 'flat' | 'bass' | 'vocal' | 'rock' | 'pop' | 'electro' | 'custom'
  audioReactive: true,
  lightsOut: false,
  lightsOutOpacity: 95,  // % dimming amount (50% to 100%)
  screenXMode: true,     // ScreenX 4-sided edge extrusion (270° frame expansion)
  abLoopEnabled: false,  // interactive A-B section repeat looper
  abLoopAutoClear: false, // auto-clear loop on video navigation
  ultrawideZoom: false,
  videoBrightness: 100,  // %
  videoContrast: 100,    // %
  videoSepia: 0,         // % — acts as blue-light filter
  autoPauseMode: 'off',  // 'off' | 'tab' | 'app'
  recordFormat: 'mkv',   // 'mkv' | 'webm' | 'mp4'
  recordFps: 30,         // 30 | 60
  returnDislikes: false, // restore public dislike count & rating
  hideShorts: false,     // hide YouTube Shorts shelves & feeds
  hideAiVideos: false,   // hide/flag videos carrying YouTube official AI disclosure
  restoreAnnotations: false, // restore classic YouTube video annotations
  hideEndCards: true     // hide video end cards, suggestions & subscribe overlays by default
});

if (typeof globalThis !== 'undefined') {
  globalThis.AURA_DEFAULTS = AURA_DEFAULTS;
}

if (typeof module === 'object' && typeof module.exports === 'object') {
  module.exports = { AURA_DEFAULTS };
}

