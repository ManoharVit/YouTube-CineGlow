/*
 * Aura – Ambient Light for YouTube (content script)
 * Author: Giri Manohar Vemula (https://www.linkedin.com/in/manoharv511)
 */
(() => {
  'use strict';

  if (typeof window !== 'undefined' && window.CineGlowKilled) return;

  const ROOT_CLASS = 'aura-active';
  const CANVAS_ID = 'aura-ambient-canvas';
  const SAMPLE_W = 128;
  const SAMPLE_H = 72;
  const SCREENX_W = 640;
  const SCREENX_H = 360;
  const SETTLE_FRAMES = 30;

  window.CineGlowMetrics = {
    renderCount: 0,
    lastDrawTime: 0,
    lastDrawStart: 0,
    lastDrawEnd: 0
  };

  let settings = { ...AURA_DEFAULTS };
  let video = null;

  let rafId = 0;
  let isActive = false;
  let lastDrawAt = 0;
  let lastVideoTime = -1;
  let settleFrames = 0;
  let forceFullDraw = true;
  let lastLayoutKey = '';
  let videoObserver = null;
  let isKilled = false;

  // ---------- Canvas setup ----------
  const canvas = document.createElement('canvas');
  canvas.id = CANVAS_ID;
  canvas.width = SAMPLE_W;
  canvas.height = SAMPLE_H;
  canvas.setAttribute('aria-hidden', 'true');
  canvas.style.pointerEvents = 'none';
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'low';

  function ensureCanvasMounted() {
    if (isKilled || window.CineGlowKilled) return;
    if (!canvas.isConnected && document.body) {
      document.body.prepend(canvas);
    }
  }

  function applyVisualSettings() {
    if (isKilled || window.CineGlowKilled) return;
    if (document.documentElement?.style?.setProperty) {
      document.documentElement.style.setProperty('--aura-opacity', String(settings.opacity / 100));
      document.documentElement.style.setProperty('--aura-fade', `${settings.fadeInDuration}s`);
    }

    const targetW = settings.screenXMode ? SCREENX_W : SAMPLE_W;
    const targetH = settings.screenXMode ? SCREENX_H : SAMPLE_H;
    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
      ctx.imageSmoothingEnabled = true;
      ctx.imageSmoothingQuality = settings.screenXMode ? 'high' : 'low';
      forceFullDraw = true;
    }

    const effectiveBlur = settings.screenXMode ? 0 : settings.blur;
    canvas.style.filter =
      `blur(${effectiveBlur}px) ` +
      `saturate(${settings.saturation / 100}) ` +
      `contrast(${settings.contrast / 100}) ` +
      `brightness(${settings.brightness / 100})`;
    lastLayoutKey = '';

    const isWatch = window.CineGlowPlayer ? window.CineGlowPlayer.isWatchPage : location.pathname === '/watch';
    document.documentElement.classList.toggle('aura-watch-page', isWatch);
    document.documentElement.classList.toggle('aura-hide-scrollbar', settings.hideScrollbar);
    document.documentElement.classList.toggle('aura-hide-theater', settings.hideInTheater);
    document.documentElement.classList.toggle('aura-adblock', settings.adblockEnabled);
    document.documentElement.classList.toggle('aura-lights-out', settings.lightsOut);
    document.documentElement.classList.toggle('aura-ultrawide-zoom', settings.ultrawideZoom);
    document.documentElement.classList.toggle('aura-screenx-mode', Boolean(settings.screenXMode));

    updatePlayingState();

    const currentVideo = video || window.CineGlowPlayer?.video;
    const isAd = Boolean(window.CineGlowPlayer?.isAdShowing);
    if (currentVideo) {
      if (isAd || (settings.videoBrightness === 100 && settings.videoContrast === 100 && settings.videoSepia === 0)) {
        currentVideo.style.filter = '';
      } else {
        currentVideo.style.filter = `brightness(${settings.videoBrightness / 100}) contrast(${settings.videoContrast / 100}) sepia(${settings.videoSepia / 100})`;
      }
    }
  }

  function updatePlayingState() {
    const currentVideo = video || window.CineGlowPlayer?.video;
    const isPlaying = currentVideo ? (!currentVideo.paused && !currentVideo.ended) : false;
    document.documentElement.classList.toggle('aura-playing', isPlaying);
  }

  function onVideoReset() {
    forceFullDraw = true;
    settleFrames = SETTLE_FRAMES;
    wake();
  }

  let videoId = null;
  let isPiP = false;

  function handlePlayerState(state) {
    if (isKilled || window.CineGlowKilled || !state) return;
    document.documentElement.classList.toggle('aura-watch-page', state.isWatchPage);
    isPiP = state.isPiP;

    if (state.video !== video || state.videoId !== videoId) {
      if (video) {
        for (const type of ['seeked', 'loadeddata', 'emptied']) {
          video.removeEventListener(type, onVideoReset);
        }
        for (const type of ['play', 'playing', 'pause', 'waiting', 'ended']) {
          video.removeEventListener(type, onVideoReset);
          video.removeEventListener(type, updatePlayingState);
        }
        if (videoObserver) {
          videoObserver.disconnect();
          videoObserver = null;
        }
      }
      video = state.video;
      videoId = state.videoId;
      if (video) {
        applyVisualSettings();
        ensureCanvasMounted();
        for (const type of ['seeked', 'loadeddata', 'emptied']) {
          video.addEventListener(type, onVideoReset, { passive: true });
        }
        for (const type of ['play', 'playing', 'pause', 'waiting', 'ended']) {
          video.addEventListener(type, onVideoReset, { passive: true });
          video.addEventListener(type, updatePlayingState, { passive: true });
        }
        updatePlayingState();

        videoObserver = new ResizeObserver(() => {
          lastLayoutKey = '';
          wake();
        });
        videoObserver.observe(video);
      }
      onVideoReset();
    } else {
      applyVisualSettings();
    }
    wake();
  }

  if (window.CineGlowPlayer) {
    window.CineGlowPlayer.addEventListener('state-change', (e) => {
      if (isKilled || window.CineGlowKilled) return;
      handlePlayerState(e.detail);
    });
    handlePlayerState(window.CineGlowPlayer);
  }

  function shouldBeActive() {
    if (!settings.enabled || document.hidden) return false;
    const state = window.CineGlowPlayer;
    if (!state || !state.isWatchPage) return false;
    if (state.isFullscreen || state.isMiniplayer) return false;
    if (isPiP && !settings.enableInPiP) return false;
    return true;
  }

  function activate() {
    if (isActive) return;
    isActive = true;
    ensureCanvasMounted();
    document.documentElement.classList.add(ROOT_CLASS);
    forceFullDraw = true;
  }

  function deactivate() {
    if (!isActive) return;
    isActive = false;
    document.documentElement.classList.remove(ROOT_CLASS);
    canvas.style.opacity = '';
    canvas.dataset.beat = '0';
    lastLayoutKey = '';
  }

  let currentLayoutX = 0;
  let currentLayoutY = 0;

  function layout(rect) {
    const scale = (settings.spread + 50) / 100;
    const w = rect.width * scale;
    const h = rect.height * scale;
    const x = rect.left - (w - rect.width) / 2;
    const y = rect.top - (h - rect.height) / 2;
    currentLayoutX = x;
    currentLayoutY = y;

    const topClip = settings.glowTop ? -h : (h - rect.height) / 2;
    const rightClip = settings.glowRight ? -w : (w - rect.width) / 2;
    const bottomClip = settings.glowBottom ? -h : (h - rect.height) / 2;
    const leftClip = settings.glowLeft ? -w : (w - rect.width) / 2;

    const key = `${x.toFixed(1)}|${y.toFixed(1)}|${w.toFixed(1)}|${h.toFixed(1)}|${topClip.toFixed(1)}|${rightClip.toFixed(1)}|${bottomClip.toFixed(1)}|${leftClip.toFixed(1)}`;
    if (key === lastLayoutKey) return;
    lastLayoutKey = key;

    canvas.style.width = `${w}px`;
    canvas.style.height = `${h}px`;
    canvas.style.transform = `translate3d(${x}px, ${y}px, 0)`;
    canvas.style.clipPath = `inset(${topClip}px ${rightClip}px ${bottomClip}px ${leftClip}px)`;
  }

  function drawScreenXFrame(v, c) {
    const W = canvas.width;
    const H = canvas.height;
    const vw = v.videoWidth;
    const vh = v.videoHeight;
    let sx = 0, sy = 0, sw = vw, sh = vh;
    if (c && (1 - c.left - c.right) > 0.05 && (1 - c.top - c.bottom) > 0.05) {
      sx = vw * c.left;
      sy = vh * c.top;
      sw = vw * (1 - c.left - c.right);
      sh = vh * (1 - c.top - c.bottom);
    }

    const scale = Math.max(1.1, (settings.spread + 50) / 100);
    const cx = Math.round(W * (scale - 1) / (2 * scale));
    const cw = Math.round(W / scale);
    const cy = Math.round(H * (scale - 1) / (2 * scale));
    const ch = Math.round(H / scale);
    const rightX = cx + cw;
    const rightW = W - rightX;
    const bottomY = cy + ch;
    const bottomH = H - bottomY;

    const edgeW = Math.max(2, Math.min(sw, sw * (cx / cw)));
    const edgeH = Math.max(2, Math.min(sh, sh * (cy / ch)));

    // Center video
    ctx.drawImage(v, sx, sy, sw, sh, cx, cy, cw, ch);

    // Left Wing (extruded leftward seamlessly from x = cx to x = 0)
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(-1, 1);
    ctx.drawImage(v, sx, sy, edgeW, sh, 0, 0, cx, ch);
    ctx.restore();

    // Right Wing (extruded rightward seamlessly from x = rightX to x = W)
    ctx.save();
    ctx.translate(rightX, cy);
    ctx.scale(-1, 1);
    ctx.drawImage(v, sx + sw - edgeW, sy, edgeW, sh, -rightW, 0, rightW, ch);
    ctx.restore();

    // Top Wing (extruded upward seamlessly from y = cy to y = 0)
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(1, -1);
    ctx.drawImage(v, sx, sy, sw, edgeH, 0, 0, cw, cy);
    ctx.restore();

    // Bottom Wing (extruded downward seamlessly from y = bottomY to y = H)
    ctx.save();
    ctx.translate(cx, bottomY);
    ctx.scale(1, -1);
    ctx.drawImage(v, sx, sy + sh - edgeH, sw, edgeH, 0, -bottomH, cw, bottomH);
    ctx.restore();

    // 4 Corners (extruded diagonally seamlessly)
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(-1, -1);
    ctx.drawImage(v, sx, sy, edgeW, edgeH, 0, 0, cx, cy);
    ctx.restore();

    ctx.save();
    ctx.translate(rightX, cy);
    ctx.scale(-1, -1);
    ctx.drawImage(v, sx + sw - edgeW, sy, edgeW, edgeH, -rightW, 0, rightW, cy);
    ctx.restore();

    ctx.save();
    ctx.translate(cx, bottomY);
    ctx.scale(-1, -1);
    ctx.drawImage(v, sx, sy + sh - edgeH, edgeW, edgeH, 0, -bottomH, cx, bottomH);
    ctx.restore();

    ctx.save();
    ctx.translate(rightX, bottomY);
    ctx.scale(-1, -1);
    ctx.drawImage(v, sx + sw - edgeW, sy + sh - edgeH, edgeW, edgeH, -rightW, -bottomH, rightW, bottomH);
    ctx.restore();
  }

  function draw(v, now) {
    if (v.readyState < 2 || v.videoWidth < 2 || v.videoHeight < 2) return true;

    const t = v.currentTime;
    if (t !== lastVideoTime) {
      settleFrames = SETTLE_FRAMES;
    } else if (!forceFullDraw && settleFrames <= 0) {
      return false;
    }

    lastDrawAt = now;
    lastVideoTime = t;
    settleFrames--;

    const smoothing = (settings.screenXMode || forceFullDraw) ? 0 : settings.smoothness / 100;
    ctx.globalAlpha = 1 - smoothing * 0.9;
    forceFullDraw = false;

    try {
      const t0 = performance.now();
      const c = window.CineGlowCrop;
      if (settings.screenXMode) {
        drawScreenXFrame(v, c);
      } else if (c && (1 - c.left - c.right) > 0.05 && (1 - c.top - c.bottom) > 0.05) {
        ctx.drawImage(
          v,
          v.videoWidth * c.left,
          v.videoHeight * c.top,
          v.videoWidth * (1 - c.left - c.right),
          v.videoHeight * (1 - c.top - c.bottom),
          0, 0, SAMPLE_W, SAMPLE_H
        );
      } else {
        ctx.drawImage(v, 0, 0, SAMPLE_W, SAMPLE_H);
      }
      const t1 = performance.now();

      window.CineGlowMetrics.lastDrawStart = t0;
      window.CineGlowMetrics.lastDrawEnd = t1;
      window.CineGlowMetrics.lastDrawTime = t1 - t0;
      window.CineGlowMetrics.renderCount++;
    } catch (_) {}

    if (settings.audioReactive && window.CineGlowAudioAnalyser && window.CineGlowAudioDataArray && !v.paused) {
      const analyser = window.CineGlowAudioAnalyser;
      const dataArray = window.CineGlowAudioDataArray;
      analyser.getByteFrequencyData(dataArray);

      let bass = 0;
      const bassBins = 8;
      for (let i = 0; i < bassBins; i++) {
        bass += dataArray[i];
      }
      bass = (bass / bassBins) / 255;

      const enhancedBass = Math.pow(bass, 1.5);
      const beatScale = 1 + (enhancedBass * 0.4);
      const beatOpacity = (settings.opacity / 100) * (1 + enhancedBass * 1.5);

      canvas.style.transform = `translate3d(${currentLayoutX}px, ${currentLayoutY}px, 0) scale(${beatScale})`;
      canvas.style.opacity = Math.min(1, beatOpacity);
      canvas.dataset.beat = '1';
    } else if (canvas.dataset.beat === '1') {
      canvas.style.transform = `translate3d(${currentLayoutX}px, ${currentLayoutY}px, 0)`;
      canvas.style.opacity = '';
      canvas.dataset.beat = '0';
    }

    return true;
  }

  function tick(now) {
    rafId = 0;
    if (isKilled || window.CineGlowKilled) return;

    const v = shouldBeActive() ? window.CineGlowPlayer.video : null;
    if (!v) {
      deactivate();
      return;
    }

    const minInterval = 1000 / Math.max(1, settings.fps || 30);
    if (!forceFullDraw && lastLayoutKey !== '' && (now - lastDrawAt < minInterval)) {
      schedule();
      return;
    }

    let rect = v.getBoundingClientRect();
    if (!rect || rect.width < 2 || rect.height < 2) {
      deactivate();
      return;
    }

    const c = window.CineGlowCrop;
    if (c && (1 - c.left - c.right) > 0.05 && (1 - c.top - c.bottom) > 0.05) {
      rect = {
        top: rect.top + rect.height * c.top,
        bottom: rect.bottom - rect.height * c.bottom,
        left: rect.left + rect.width * c.left,
        right: rect.right - rect.width * c.right,
        width: rect.width * (1 - c.left - c.right),
        height: rect.height * (1 - c.top - c.bottom)
      };
    }

    activate();
    layout(rect);
    const keepRunning = draw(v, now);
    if (keepRunning) {
      schedule();
    }
  }

  function schedule() {
    if (isKilled || window.CineGlowKilled || rafId) return;
    rafId = requestAnimationFrame(tick);
  }

  function wake() {
    if (isKilled || window.CineGlowKilled) return;
    schedule();
  }

  const handleViewportChange = () => {
    lastLayoutKey = '';
    wake();
  };

  // ---------- Settings ----------
  async function loadSettings() {
    if (isKilled || window.CineGlowKilled) return;
    try {
      if (typeof chrome !== 'undefined' && chrome.storage) {
        const local = await chrome.storage.local?.get(['auraKillSwitchActive']).catch(() => ({}));
        if (local?.auraKillSwitchActive) {
          teardownKillSwitch();
          return;
        }
        const managed = await chrome.storage.managed?.get(['KillSwitch']).catch(() => ({}));
        if (managed?.KillSwitch) {
          teardownKillSwitch();
          return;
        }
      }
      const stored = await chrome.storage.sync.get(AURA_DEFAULTS);
      settings = { ...AURA_DEFAULTS, ...stored };
    } catch (err) {
      console.warn('[Aura] Could not load settings, using defaults:', err);
    }
    applyVisualSettings();
    wake();
  }

  const handleStorageChange = (changes, area) => {
    if (isKilled || window.CineGlowKilled) return;
    if (area === 'managed' && changes.KillSwitch?.newValue === true) {
      teardownKillSwitch();
      return;
    }
    if (area === 'local' && changes.auraKillSwitchActive?.newValue === true) {
      teardownKillSwitch();
      return;
    }
    if (area !== 'sync') return;
    for (const [key, { newValue }] of Object.entries(changes)) {
      if (key in AURA_DEFAULTS) {
        settings[key] = newValue ?? AURA_DEFAULTS[key];
      }
    }
    applyVisualSettings();
    forceFullDraw = true;
    wake();
  };
  chrome.storage?.onChanged?.addListener(handleStorageChange);

  // ---------- Clean Theater Mode: Top Search Bar Hover-to-Reveal ----------
  let theaterHoverTimer = null;

  function isSearchFocused() {
    const el = document.activeElement;
    if (!el) return false;
    const tag = el.tagName?.toLowerCase();
    return (
      el.id === 'search' ||
      el.closest?.('#masthead-container, ytd-masthead, #search-form') ||
      (tag === 'input' && el.getAttribute('name') === 'search_query')
    );
  }

  function handleTheaterHover(e) {
    if (isKilled || !settings.hideInTheater) return;
    const isWatch = window.CineGlowPlayer ? window.CineGlowPlayer.isWatchPage : location.pathname === '/watch';
    const isTheater = window.CineGlowPlayer ? window.CineGlowPlayer.isTheater : false;
    if (!isWatch || !isTheater) {
      document.documentElement.classList.remove('aura-theater-reveal-top');
      return;
    }

    if (e.clientY <= 64) {
      clearTimeout(theaterHoverTimer);
      document.documentElement.classList.add('aura-theater-reveal-top');
    } else if (e.clientY > 80 && !isSearchFocused()) {
      clearTimeout(theaterHoverTimer);
      theaterHoverTimer = setTimeout(() => {
        if (!isSearchFocused()) {
          document.documentElement.classList.remove('aura-theater-reveal-top');
        }
      }, 1200);
    }
  }

  window.addEventListener('mousemove', handleTheaterHover, { passive: true });

  // ---------- Emergency Kill-Switch Teardown ----------
  function teardownKillSwitch() {
    if (isKilled) return;
    isKilled = true;
    isActive = false;
    window.CineGlowKilled = true;
    clearTimeout(theaterHoverTimer);
    chrome.storage?.onChanged?.removeListener(handleStorageChange);
    window.removeEventListener('mousemove', handleTheaterHover);
    window.removeEventListener('resize', handleViewportChange);
    window.removeEventListener('scroll', handleViewportChange);

    if (rafId) {
      cancelAnimationFrame(rafId);
      rafId = 0;
    }

    if (videoObserver) {
      videoObserver.disconnect();
      videoObserver = null;
    }

    document.getElementById(CANVAS_ID)?.remove();
    canvas?.remove();

    if (document.documentElement) {
      document.documentElement.classList.remove(
        ROOT_CLASS,
        'aura-active',
        'aura-playing',
        'aura-watch-page',
        'aura-adblock',
        'aura-lights-out',
        'aura-ultrawide-zoom',
        'aura-screenx-mode',
        'aura-hide-scrollbar',
        'aura-hide-theater',
        'aura-theater-reveal-top'
      );
      document.documentElement.style?.removeProperty('--aura-opacity');
      document.documentElement.style?.removeProperty('--aura-fade');
    }

    const currentVideo = video || window.CineGlowPlayer?.video;
    if (currentVideo) {
      currentVideo.style.filter = '';
      for (const type of ['seeked', 'loadeddata', 'emptied', 'play', 'playing', 'pause', 'waiting', 'ended']) {
        currentVideo.removeEventListener(type, onVideoReset);
        currentVideo.removeEventListener(type, updatePlayingState);
      }
    }
    video = null;

    document.removeEventListener('visibilitychange', wake);

    if (window.CineGlowMetrics) {
      window.CineGlowMetrics.renderCount = 0;
    }
  }

  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage?.addListener) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message?.type === 'AURA_EMERGENCY_KILL_SWITCH') {
        teardownKillSwitch();
        if (!window._cineglowKillEventFired) {
          window._cineglowKillEventFired = true;
          window.dispatchEvent(new CustomEvent('cineglow:kill-switch', { detail: message }));
        }
        if (typeof sendResponse === 'function') {
          sendResponse({ success: true, script: 'content.js' });
        }
      }
    });
  }

  window.addEventListener('cineglow:kill-switch', () => {
    teardownKillSwitch();
  }, { once: true });

  window.CineGlowTeardown = teardownKillSwitch;

  document.addEventListener('visibilitychange', wake);
  window.addEventListener('resize', handleViewportChange, { passive: true });
  window.addEventListener('scroll', handleViewportChange, { passive: true });

  window.addEventListener('unhandledrejection', (event) => {
    if (event?.reason && String(event.reason.message || event.reason).includes('Extension context invalidated')) {
      try { event.preventDefault(); } catch (_) {}
    }
  });
  window.addEventListener('error', (event) => {
    if (event?.message && String(event.message).includes('Extension context invalidated')) {
      try { event.preventDefault(); } catch (_) {}
    }
  });

  loadSettings();
})();
