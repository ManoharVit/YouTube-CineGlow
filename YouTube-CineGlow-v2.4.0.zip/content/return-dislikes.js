(() => {
  'use strict';

  const API_ENDPOINT = 'https://returnyoutubedislikeapi.com/votes?videoId=';
  const DISLIKE_COUNT_CLASS = 'cineglow-dislike-count';
  const HAS_DISLIKES_CLASS = 'cineglow-has-dislikes';
  const RATIO_BAR_CLASS = 'cineglow-ratio-bar';

  let isEnabled = false;
  let currentVideoId = null;
  let votesCache = new Map(); // videoId -> { id, likes, dislikes, rating, viewCount, userVote }
  let domObserver = null;
  let fetchAbortController = null;
  let isUpdating = false;
  let isKilled = false;

  // Compact number formatting (e.g. 521K, 1.4M, 245)
  function formatCount(num) {
    if (num == null || isNaN(num)) return '';
    if (num < 1000) return String(num);

    try {
      const formatter = new Intl.NumberFormat(navigator.language || 'en', {
        notation: 'compact',
        compactDisplay: 'short',
        maximumFractionDigits: 1
      });
      return formatter.format(num);
    } catch {
      if (num >= 1e6) return (num / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
      if (num >= 1e3) return (num / 1e3).toFixed(1).replace(/\.0$/, '') + 'K';
      return String(num);
    }
  }

  // Extract current video ID from URL or player state
  function getVideoId() {
    // 1. Standard watch page: /watch?v=...
    const urlParams = new URLSearchParams(window.location.search);
    const v = urlParams.get('v');
    if (v) return v;

    // 2. Shorts: /shorts/...
    if (window.location.pathname.startsWith('/shorts/')) {
      const parts = window.location.pathname.split('/shorts/');
      if (parts[1]) {
        return parts[1].split('/')[0].split('?')[0];
      }
    }

    // 3. Fallback: window.CineGlowPlayer state
    if (window.CineGlowPlayer && window.CineGlowPlayer.videoId) {
      return window.CineGlowPlayer.videoId;
    }

    return null;
  }

  // Fetch votes from Return YouTube Dislike API
  async function fetchVotes(videoId) {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return null;
    if (!videoId) return null;

    if (votesCache.has(videoId)) {
      return votesCache.get(videoId);
    }

    if (fetchAbortController) {
      fetchAbortController.abort();
    }
    fetchAbortController = new AbortController();

    try {
      const result = await new Promise((resolve) => {
        try {
          if (!chrome.runtime?.id) {
            resolve(null);
            return;
          }
          chrome.runtime.sendMessage({ type: 'FETCH_DISLIKES', videoId }, (res) => {
            try {
              if (chrome.runtime?.lastError || !res || !res.success) {
                resolve(null);
              } else {
                resolve(res.data);
              }
            } catch (_) {
              resolve(null);
            }
          });
        } catch (_) {
          resolve(null);
        }
      });

      if (!result || typeof result.dislikes !== 'number') return null;

      const voteRecord = {
        id: videoId,
        likes: Number(result.likes) || 0,
        dislikes: Number(result.dislikes) || 0,
        rating: Number(result.rating) || 5,
        viewCount: Number(result.viewCount) || 0,
        userVote: 0 // 0 = none, 1 = liked, -1 = disliked
      };

      votesCache.set(videoId, voteRecord);

      // Keep cache bounded to 100 entries
      if (votesCache.size > 100) {
        const oldestKey = votesCache.keys().next().value;
        votesCache.delete(oldestKey);
      }

      return voteRecord;
    } catch (err) {
      // Silently handle errors
    }

    return null;
  }

  // Locate like & dislike button elements across modern Polymer and legacy templates
  function findDislikeElements() {
    // Modern segmented like/dislike buttons
    const segmentedWrapper = document.querySelector('.ytSegmentedLikeDislikeButtonViewModelSegmentedButtonsWrapper') ||
                            document.querySelector('segmented-like-dislike-button-view-model');

    if (segmentedWrapper) {
      const dislikeBtn = segmentedWrapper.querySelector('dislike-button-view-model button') ||
                         segmentedWrapper.querySelector('#dislike-button button') ||
                         segmentedWrapper.querySelector('button:last-of-type');

      const likeBtn = segmentedWrapper.querySelector('like-button-view-model button') ||
                      segmentedWrapper.querySelector('#like-button button') ||
                      segmentedWrapper.querySelector('button:first-of-type');

      if (dislikeBtn) {
        return {
          dislikeBtn,
          likeBtn,
          wrapper: segmentedWrapper,
          isShorts: false
        };
      }
    }

    // Direct dislike-button-view-model query
    const dislikeVm = document.querySelector('dislike-button-view-model button');
    if (dislikeVm) {
      const likeVm = document.querySelector('like-button-view-model button');
      return {
        dislikeBtn: dislikeVm,
        likeBtn: likeVm,
        wrapper: dislikeVm.closest('segmented-like-dislike-button-view-model') || dislikeVm.parentElement,
        isShorts: false
      };
    }

    // Legacy segmented button renderer
    const legacyDislike = document.querySelector('#segmented-dislike-button button, ytd-segmented-like-dislike-button-renderer #dislike-button button');
    if (legacyDislike) {
      const legacyLike = document.querySelector('#segmented-like-button button, ytd-segmented-like-dislike-button-renderer #like-button button');
      return {
        dislikeBtn: legacyDislike,
        likeBtn: legacyLike,
        wrapper: legacyDislike.closest('ytd-segmented-like-dislike-button-renderer') || legacyDislike.parentElement,
        isShorts: false
      };
    }

    // YouTube Shorts dislike button
    if (window.location.pathname.startsWith('/shorts/')) {
      const activeReel = document.querySelector('ytd-reel-video-renderer[is-active]') || document.querySelector('ytd-reel-video-renderer');
      if (activeReel) {
        const shortsDislike = activeReel.querySelector('#dislike-button');
        if (shortsDislike) {
          const shortsBtn = shortsDislike.querySelector('button') || shortsDislike;
          const shortsLike = activeReel.querySelector('#like-button');
          return {
            dislikeBtn: shortsBtn,
            likeBtn: shortsLike ? (shortsLike.querySelector('button') || shortsLike) : null,
            wrapper: shortsDislike,
            isShorts: true
          };
        }
      }
    }

    return null;
  }

  // Render dislike count and ratio bar safely into the DOM (Trusted Types compliant)
  function renderDislikes(voteRecord) {
    if (!isEnabled || !voteRecord) return;

    const elements = findDislikeElements();
    if (!elements || !elements.dislikeBtn) return;

    const { dislikeBtn, likeBtn, wrapper, isShorts } = elements;

    const formattedExact = voteRecord.dislikes.toLocaleString();
    const formattedCompact = formatCount(voteRecord.dislikes);

    // Update dislike button attributes
    dislikeBtn.title = `${formattedExact} dislikes`;
    dislikeBtn.setAttribute('aria-label', `Dislike this video along with ${formattedExact} other people`);
    dislikeBtn.classList.add(HAS_DISLIKES_CLASS);
    dislikeBtn.classList.remove('ytSpecButtonShapeNextIconButton');

    // Update or create dislike count element
    let countEl = dislikeBtn.querySelector(`.${DISLIKE_COUNT_CLASS}`);
    if (!countEl) {
      countEl = document.createElement('div');
      countEl.className = `ytSpecButtonShapeNextButtonTextContent ytSpecButtonShapeNextElevatedContent ${DISLIKE_COUNT_CLASS}`;
      countEl.setAttribute('aria-hidden', 'true');

      const feedback = dislikeBtn.querySelector('yt-touch-feedback-shape');
      if (feedback) {
        dislikeBtn.insertBefore(countEl, feedback);
      } else {
        dislikeBtn.appendChild(countEl);
      }
    }

    if (countEl.textContent !== formattedCompact) {
      countEl.textContent = formattedCompact;
    }

    // Render Like/Dislike Ratio Bar on watch page
    if (!isShorts && wrapper) {
      renderRatioBar(wrapper, voteRecord.likes, voteRecord.dislikes);
    }

    // Attach optimistic voting listeners
    attachVoteListeners(dislikeBtn, likeBtn, voteRecord);
  }

  // Render or update rating ratio bar underneath the segmented buttons
  function renderRatioBar(wrapper, likes, dislikes) {
    const parentContainer = wrapper.parentElement || wrapper;
    let ratioBar = parentContainer.querySelector(`.${RATIO_BAR_CLASS}`);

    if (!ratioBar) {
      ratioBar = document.createElement('div');
      ratioBar.className = RATIO_BAR_CLASS;

      const likesBar = document.createElement('div');
      likesBar.className = 'cineglow-ratio-likes';

      const dislikesBar = document.createElement('div');
      dislikesBar.className = 'cineglow-ratio-dislikes';

      ratioBar.appendChild(likesBar);
      ratioBar.appendChild(dislikesBar);
      parentContainer.appendChild(ratioBar);
    }

    const total = likes + dislikes;
    const likePercent = total > 0 ? (likes / total) * 100 : 50;

    const likesBar = ratioBar.querySelector('.cineglow-ratio-likes');
    if (likesBar) {
      likesBar.style.width = `${likePercent.toFixed(1)}%`;
    }

    ratioBar.title = `${likes.toLocaleString()} likes / ${dislikes.toLocaleString()} dislikes (${likePercent.toFixed(1)}%)`;
  }

  // Optimistic click feedback for like and dislike buttons
  function attachVoteListeners(dislikeBtn, likeBtn, voteRecord) {
    if (dislikeBtn) {
      dislikeBtn._currentVoteRecord = voteRecord;
      if (!dislikeBtn._cineglowDislikeBound) {
        const dislikeHandler = () => {
          const record = dislikeBtn._currentVoteRecord || voteRecord;
          if (!isEnabled || !record) return;

          setTimeout(() => {
            const isPressed = dislikeBtn.getAttribute('aria-pressed') === 'true';
            if (isPressed && record.userVote !== -1) {
              if (record.userVote === 1) {
                record.likes = Math.max(0, record.likes - 1);
              }
              record.dislikes += 1;
              record.userVote = -1;
            } else if (!isPressed && record.userVote === -1) {
              record.dislikes = Math.max(0, record.dislikes - 1);
              record.userVote = 0;
            }
            renderDislikes(record);
          }, 50);
        };
        dislikeBtn._cineglowDislikeHandler = dislikeHandler;
        dislikeBtn._cineglowDislikeBound = true;
        dislikeBtn.addEventListener('click', dislikeHandler);
      }
    }

    if (likeBtn) {
      likeBtn._currentVoteRecord = voteRecord;
      if (!likeBtn._cineglowLikeBound) {
        const likeHandler = () => {
          const record = likeBtn._currentVoteRecord || voteRecord;
          if (!isEnabled || !record) return;

          setTimeout(() => {
            const isPressed = likeBtn.getAttribute('aria-pressed') === 'true';
            if (isPressed && record.userVote !== 1) {
              if (record.userVote === -1) {
                record.dislikes = Math.max(0, record.dislikes - 1);
              }
              record.likes += 1;
              record.userVote = 1;
            } else if (!isPressed && record.userVote === 1) {
              record.likes = Math.max(0, record.likes - 1);
              record.userVote = 0;
            }
            renderDislikes(record);
          }, 50);
        };
        likeBtn._cineglowLikeHandler = likeHandler;
        likeBtn._cineglowLikeBound = true;
        likeBtn.addEventListener('click', likeHandler);
      }
    }
  }

  // Clean teardown when user disables Return YouTube Dislike
  function teardown() {
    if (domObserver) {
      domObserver.disconnect();
      domObserver = null;
    }

    if (fetchAbortController) {
      fetchAbortController.abort();
      fetchAbortController = null;
    }

    // Remove injected dislike counters
    document.querySelectorAll(`.${DISLIKE_COUNT_CLASS}`).forEach(el => el.remove());

    // Remove ratio bars
    document.querySelectorAll(`.${RATIO_BAR_CLASS}`).forEach(el => el.remove());

    // Restore dislike button styling & attributes
    document.querySelectorAll(`.${HAS_DISLIKES_CLASS}`).forEach(btn => {
      btn.classList.remove(HAS_DISLIKES_CLASS);
      btn.removeAttribute('title');
      btn.setAttribute('aria-label', 'Dislike this video');
      if (typeof btn.removeEventListener === 'function' && btn._cineglowDislikeHandler) {
        btn.removeEventListener('click', btn._cineglowDislikeHandler);
      }
      delete btn._cineglowDislikeHandler;
      delete btn._currentVoteRecord;
      delete btn._cineglowDislikeBound;
    });

    document.querySelectorAll('dislike-button-view-model button, #dislike-button button').forEach(btn => {
      if (typeof btn.removeEventListener === 'function' && btn._cineglowDislikeHandler) {
        btn.removeEventListener('click', btn._cineglowDislikeHandler);
      }
      delete btn._cineglowDislikeHandler;
      delete btn._currentVoteRecord;
      delete btn._cineglowDislikeBound;
    });

    document.querySelectorAll('like-button-view-model button, #like-button button').forEach(btn => {
      if (typeof btn.removeEventListener === 'function' && btn._cineglowLikeHandler) {
        btn.removeEventListener('click', btn._cineglowLikeHandler);
      }
      delete btn._cineglowLikeHandler;
      delete btn._currentVoteRecord;
      delete btn._cineglowLikeBound;
    });
  }

  // Update dislikes for currently playing video
  async function updateForCurrentVideo() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (!isEnabled || isUpdating) return;
    isUpdating = true;

    try {
      const videoId = getVideoId();
      if (!videoId) return;

      currentVideoId = videoId;
      const voteData = await fetchVotes(videoId);

      // Verify video didn't change while fetch was in-flight
      if (voteData && getVideoId() === videoId) {
        renderDislikes(voteData);
      }
    } finally {
      isUpdating = false;
    }
  }

  // Watch DOM mutations to ensure dislike counter stays rendered across Polymer updates
  function startObserver() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (domObserver || !isEnabled) return;

    domObserver = new MutationObserver(() => {
      if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
      if (!isEnabled) return;

      const vid = getVideoId();
      if (vid && vid !== currentVideoId) {
        currentVideoId = vid;
        updateForCurrentVideo();
        return;
      }

      // Check if dislike button exists but is missing our counter
      const elements = findDislikeElements();
      if (elements && elements.dislikeBtn) {
        if (!elements.dislikeBtn.querySelector(`.${DISLIKE_COUNT_CLASS}`)) {
          if (currentVideoId && votesCache.has(currentVideoId)) {
            renderDislikes(votesCache.get(currentVideoId));
          } else {
            updateForCurrentVideo();
          }
        }
      }
    });

    domObserver.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  function initialize() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (!isEnabled) return;
    updateForCurrentVideo();
    startObserver();
  }

  // Emergency Kill-Switch Teardown
  function teardownKillSwitch() {
    if (isKilled) return;
    isKilled = true;
    isEnabled = false;
    if (typeof window !== 'undefined') window.CineGlowKilled = true;

    teardown();
    votesCache.clear();
    document.removeEventListener('yt-navigate-finish', updateForCurrentVideo);
  }

  // Dual listener registration: Direct runtime message + In-tab fallback event
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage?.addListener) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message && message.type === 'AURA_EMERGENCY_KILL_SWITCH') {
        teardownKillSwitch();
        if (typeof window !== 'undefined' && !window._cineglowKillEventFired) {
          window._cineglowKillEventFired = true;
          window.dispatchEvent(new CustomEvent('cineglow:kill-switch', { detail: message }));
        }
        if (typeof sendResponse === 'function') {
          sendResponse({ success: true, script: 'return-dislikes.js' });
        }
      }
    });
  }

  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('cineglow:kill-switch', () => {
      teardownKillSwitch();
    }, { once: true });
  }

  window.CineGlowDislikesTeardown = teardownKillSwitch;

  // YouTube SPA Navigation listeners
  document.addEventListener('yt-navigate-finish', () => {
    if (isEnabled && !isKilled) {
      updateForCurrentVideo();
    }
  });

  if (window.CineGlowPlayer) {
    window.CineGlowPlayer.addEventListener('state-change', () => {
      if (isEnabled && !isKilled) {
        const vid = getVideoId();
        if (vid !== currentVideoId) {
          updateForCurrentVideo();
        }
      }
    });
  }

  // Load setting from storage (default: false)
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.sync) {
    chrome.storage.sync.get({ returnDislikes: false }, (items) => {
      if (isKilled) return;
      isEnabled = !!items.returnDislikes;
      if (isEnabled) {
        initialize();
      }
    });

    chrome.storage.onChanged.addListener((changes, area) => {
      if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
      if (area === 'sync' && 'returnDislikes' in changes) {
        isEnabled = !!changes.returnDislikes.newValue;
        if (isEnabled) {
          initialize();
        } else {
          teardown();
        }
      }
    });
  }

  // Initial check when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (isEnabled && !isKilled) initialize();
    });
  } else {
    if (isEnabled && !isKilled) initialize();
  }

  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('unhandledrejection', (event) => {
      if (event && event.reason && String(event.reason.message || event.reason).includes('Extension context invalidated')) {
        try { event.preventDefault(); } catch (_) {}
      }
    });
    window.addEventListener('error', (event) => {
      if (event && event.message && String(event.message).includes('Extension context invalidated')) {
        try { event.preventDefault(); } catch (_) {}
      }
    });
  }
})();
