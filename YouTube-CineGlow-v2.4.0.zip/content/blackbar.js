/*
 * Aura - Black Bar Detection and Removal (Auto-Crop)
 * Production Architecture: OffscreenCanvas + Synchronous Low-Overhead Frame Analysis
 * Note: Avoids Blob Web Workers to comply strictly with YouTube Content Security Policy (script-src/worker-src).
 */
(() => {
  'use strict';

  let settings = { ...AURA_DEFAULTS };
  let video = null;
  let videoId = null;
  let isAdShowing = false;
  let intervalId = null;
  let isKilled = false;
  
  // Downsampled OffscreenCanvas (64x64) eliminates GPU readback stalls
  const SCAN_WIDTH = 64;
  const SCAN_HEIGHT = 64;
  let offscreenCanvas = null;
  let offscreenCtx = null;

  if (typeof OffscreenCanvas !== 'undefined') {
    try {
      offscreenCanvas = new OffscreenCanvas(SCAN_WIDTH, SCAN_HEIGHT);
      offscreenCtx = offscreenCanvas.getContext('2d', { willReadFrequently: true });
    } catch (_) {
      offscreenCanvas = null;
    }
  }

  const canvas = offscreenCanvas || document.createElement('canvas');
  canvas.width = SCAN_WIDTH;
  canvas.height = SCAN_HEIGHT;
  const ctx = offscreenCtx || (canvas.getContext && canvas.getContext('2d', { willReadFrequently: true }));

  const STABLE_THRESHOLD = 8;
  const STABILITY_REQUIRED = STABLE_THRESHOLD;
  let stableCrop = { top: 0, bottom: 0, left: 0, right: 0 };
  let candidateCrop = { top: 0, bottom: 0, left: 0, right: 0 };
  let stabilityCount = 0;
  let lastUnfocusedScan = 0;

  function calculateCropFromDimensions(topBar, bottomBar, leftBar, rightBar, width, height) {
    if (topBar === height || leftBar === width) return;
    const overscanY = (topBar > 0 || bottomBar > 0) ? 0.006 : 0;
    const overscanX = (leftBar > 0 || rightBar > 0) ? 0.006 : 0;

    const cropTop = topBar > 0 ? (topBar / height) + overscanY : 0;
    const cropBottom = bottomBar > 0 ? (bottomBar / height) + overscanY : 0;
    const cropLeft = leftBar > 0 ? (leftBar / width) + overscanX : 0;
    const cropRight = rightBar > 0 ? (rightBar / width) + overscanX : 0;

    handleCropResult({ cropTop, cropBottom, cropLeft, cropRight });
  }

  function handleCropResult(result) {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (!video || !settings.removeBlackBars) return;
    
    // Ignore unreasonable crops (no real video has >25% black bars on one side)
    // Also ignore highly asymmetric crops (real black bars are roughly equal on both sides)
    if (result.cropTop > 0.25 || result.cropBottom > 0.25 || result.cropLeft > 0.25 || result.cropRight > 0.25) {
      return; 
    }
    if (Math.abs(result.cropTop - result.cropBottom) > 0.05) return;
    if (Math.abs(result.cropLeft - result.cropRight) > 0.05) return;
    
    const tolerance = 0.02;
    const isSameCandidate = 
      Math.abs(result.cropTop - candidateCrop.top) < tolerance &&
      Math.abs(result.cropBottom - candidateCrop.bottom) < tolerance &&
      Math.abs(result.cropLeft - candidateCrop.left) < tolerance &&
      Math.abs(result.cropRight - candidateCrop.right) < tolerance;
      
    if (isSameCandidate) {
      stabilityCount++;
      if (stabilityCount === STABLE_THRESHOLD) {
        applyCrop(candidateCrop);
      }
    } else {
      candidateCrop = {
        top: result.cropTop,
        bottom: result.cropBottom,
        left: result.cropLeft,
        right: result.cropRight
      };
      stabilityCount = 1;
    }
  }

  function applyCrop(crop) {
    const isDifferent = 
      Math.abs(crop.top - stableCrop.top) > 0.01 ||
      Math.abs(crop.bottom - stableCrop.bottom) > 0.01 ||
      Math.abs(crop.left - stableCrop.left) > 0.01 ||
      Math.abs(crop.right - stableCrop.right) > 0.01;
      
    if (isDifferent) {
      stableCrop = { ...crop };
      
      if (crop.top || crop.right || crop.bottom || crop.left) {
        window.CineGlowCrop = stableCrop;
        video.style.clipPath = `inset(${crop.top * 100}% ${crop.right * 100}% ${crop.bottom * 100}% ${crop.left * 100}%)`;
      } else {
        resetCrop();
      }
    }
  }

  function resetCrop() {
    window.CineGlowCrop = null;
    stableCrop = { top: 0, bottom: 0, left: 0, right: 0 };
    candidateCrop = { top: 0, bottom: 0, left: 0, right: 0 };
    stabilityCount = 0;
    if (video) {
      video.style.clipPath = '';
    }
  }

  function processScan(data, width, height) {
    const threshold = 15;
    function isBlack(x, y) {
      const i = (y * width + x) * 4;
      return data[i] <= threshold && data[i+1] <= threshold && data[i+2] <= threshold;
    }
    function isRowBlack(y) {
      const startX = Math.floor(width * 0.05);
      const endX = Math.floor(width * 0.95);
      const tolerance = Math.max(1, Math.floor((endX - startX) * 0.05));
      let nonBlack = 0;
      for (let x = startX; x < endX; x++) {
        if (!isBlack(x, y)) {
          nonBlack++;
          if (nonBlack > tolerance) return false;
        }
      }
      return true;
    }
    function isColBlack(x) {
      const startY = Math.floor(height * 0.25);
      const endY = Math.floor(height * 0.75);
      const tolerance = Math.max(1, Math.floor((endY - startY) * 0.05));
      let nonBlack = 0;
      for (let y = startY; y < endY; y++) {
        if (!isBlack(x, y)) {
          nonBlack++;
          if (nonBlack > tolerance) return false;
        }
      }
      return true;
    }
    let topBar = height;
    for (let y = 0; y < height; y++) {
      if (!isRowBlack(y)) { topBar = y; break; }
    }
    let bottomBar = height;
    for (let y = height - 1; y >= 0; y--) {
      if (!isRowBlack(y)) { bottomBar = height - 1 - y; break; }
    }
    let leftBar = width;
    for (let x = 0; x < width; x++) {
      if (!isColBlack(x)) { leftBar = x; break; }
    }
    let rightBar = width;
    for (let x = width - 1; x >= 0; x--) {
      if (!isColBlack(x)) { rightBar = width - 1 - x; break; }
    }
    calculateCropFromDimensions(topBar, bottomBar, leftBar, rightBar, width, height);
  }

  function scanFrame() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (!settings.removeBlackBars || isAdShowing || !video || video.readyState < 2 || video.paused) {
      return;
    }
    if (typeof document !== 'undefined' && document.hidden) {
      return;
    }
    if (typeof document !== 'undefined' && typeof document.hasFocus === 'function' && !document.hasFocus()) {
      const now = Date.now();
      if (now - lastUnfocusedScan < 2000) {
        return;
      }
      lastUnfocusedScan = now;
    }
    
    try {
      if (!ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      if (!imageData || !imageData.data) return;

      processScan(imageData.data, canvas.width, canvas.height);
    } catch (err) {
      console.debug('[Aura] BlackBar drawImage failed:', err);
    }
  }

  function startScanning() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    if (!intervalId) {
      intervalId = setInterval(() => {
        if (!video || video.paused) return;
        scanFrame();
      }, 500);
    }
  }

  function stopScanning() {
    if (intervalId) {
      clearInterval(intervalId);
      intervalId = null;
    }
    lastUnfocusedScan = 0;
  }

  function handlePlayerState(state) {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    const nextAdShowing = !!state.isAdShowing;
    if (state.video !== video || state.videoId !== videoId || nextAdShowing !== isAdShowing) {
      resetCrop();
      video = state.video;
      videoId = state.videoId;
      isAdShowing = nextAdShowing;
    }
    
    if (state.isWatchPage && video && !isAdShowing) {
      startScanning();
    } else {
      stopScanning();
      resetCrop();
    }
  }

  // --- Emergency Kill-Switch Teardown ---
  function teardownKillSwitch() {
    if (isKilled) return;
    isKilled = true;
    settings.removeBlackBars = false;
    if (typeof window !== 'undefined') window.CineGlowKilled = true;

    stopScanning();
    resetCrop();
    window.CineGlowCrop = null;
    video = null;
  }

  // Dual listener registration: Direct runtime message + In-tab fallback event
  if (typeof chrome !== 'undefined' && chrome.runtime?.onMessage?.addListener) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (message && message.type === 'AURA_EMERGENCY_KILL_SWITCH') {
        teardownKillSwitch();
        if (typeof window !== 'undefined' && !window._cineglowKillEventFired) {
          window._cineglowKillEventFired = true;
          window.dispatchEvent(new CustomEvent('cineglow:kill-switch', { detail: message }));
        }
        if (typeof sendResponse === 'function') {
          sendResponse({ success: true, script: 'blackbar.js' });
        }
      }
    });
  }

  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('cineglow:kill-switch', () => {
      teardownKillSwitch();
    }, { once: true });
  }

  window.CineGlowCropTeardown = teardownKillSwitch;

  if (window.CineGlowPlayer) {
    window.CineGlowPlayer.addEventListener('state-change', (e) => handlePlayerState(e.detail));
    handlePlayerState(window.CineGlowPlayer);
  }

  async function loadSettings() {
    if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
    try {
      const stored = await chrome.storage.sync.get(AURA_DEFAULTS);
      settings = { ...AURA_DEFAULTS, ...stored };
    } catch (err) {}
    
    if (!settings.removeBlackBars) {
      resetCrop();
    }
  }

  if (typeof chrome !== 'undefined' && chrome.storage?.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (isKilled || (typeof window !== 'undefined' && window.CineGlowKilled)) return;
      if (area !== 'sync') return;
      let changed = false;
      for (const [key, { newValue }] of Object.entries(changes)) {
        if (key in AURA_DEFAULTS) {
          settings[key] = newValue ?? AURA_DEFAULTS[key];
          changed = true;
        }
      }
      if (changed && !settings.removeBlackBars) {
        resetCrop();
      }
    });
  }

  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('unhandledrejection', (event) => {
      if (event && event.reason && String(event.reason.message || event.reason).includes('Extension context invalidated')) {
        try { event.preventDefault(); } catch (_) {}
      }
    });
    window.addEventListener('error', (event) => {
      if (event && event.message && String(event.message).includes('Extension context invalidated')) {
        try { event.preventDefault(); } catch (_) {}
      }
    });
  }

  loadSettings();
})();
